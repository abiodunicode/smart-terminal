
<template>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header p-2">
                            <ul class="nav nav-pills">
                                
                                <li class="nav-item"><router-link to="/bl-cargo" class="nav-link ">BL/Cargo Info</router-link></li>
                                <li class="nav-item"><router-link to="/telex" class="nav-link active show">Telex</router-link></li>
                                <li class="nav-item"><router-link to="/exit" class="nav-link ">Exit Note </router-link></li>
                              
                            </ul>
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <div class="tab-content">
                                <!-- Activity Tab -->
                                <div class="tab-pane active show" id="activity">
                                     <iframe 
                                height="500px"
                                width="100%"
                                frameborder="0"
                                allowTransparency="true"
                                scrolling="auto"
              src="https://creatorapp.zohopublic.com/sageplatform/ebs/form-embed/Telex_Enquiry_Form/1qPOm2aAKzMUuWKQbQvAg6bfGjfThQtV2SX9u07uanp4R5bwJrGb91F00SfjBavmfRvvJudrQtpjY6HJXuPw1Cz8u5wYTU7D4ZWy"
                                
                                      ></iframe>
                                </div>
                                <!-- Setting Tab -->
                             

                                <!-- Setting Tab -->
                            
                            <!-- /.tab-pane -->
                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
            </div>
            <!-- end tabs -->
            </div>
        </div>
    </section>
</template>

<script>
    export default {
      
        mounted() {
            console.log('Component mounted.')
        },
      

       
    }
</script>


