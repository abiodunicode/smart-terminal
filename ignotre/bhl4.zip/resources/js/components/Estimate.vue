
<template>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header p-2">
                            <ul class="nav nav-pills">
                                
                                <li class="nav-item"><router-link to="/estimate" class="nav-link active show">Estimate</router-link></li>
                                <li class="nav-item"><router-link to="/actual" class="nav-link ">Actual</router-link></li>
                               
                              
                            </ul>
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <div class="tab-content">
                                <!-- Activity Tab -->
                                <div class="tab-pane active show" id="activity">
                                     <iframe 
                                height="500px"
                                width="100%"
                                frameborder="0"
                                allowTransparency="true"
                                scrolling="auto"
              src="https://creatorapp.zohopublic.com/sageplatform/ebs/form-embed/Get_Estimated_Invoice/KAwNkOUZABrC8DQUC3jSOKmqQsah2RS84QbKgFOGQ0hpn7kkZxC0SrxAK2uOyE67Ch0mdAOnuZmt0r8HfsBWWbf1yFJ3XJOrBQyX"
                                 
                                   ></iframe>
                                </div>
                                <!-- Setting Tab -->
                             

                                <!-- Setting Tab -->
                            
                            <!-- /.tab-pane -->
                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
            </div>
            <!-- end tabs -->
            </div>
        </div>
    </section>
</template>

<script>
    export default {
      
        mounted() {
            console.log('Component mounted.')
        },
      

       
    }
</script>


