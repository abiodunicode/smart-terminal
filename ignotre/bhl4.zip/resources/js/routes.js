export default [
    { path: '/', component: require('./components/Home.vue').default },
    { path: '/bl-cargo', component: require('./components/Enquiry/Blcargo.vue').default },
    { path: '/telex', component: require('./components/Enquiry/Telex.vue').default },
    { path: '/exit', component: require('./components/Enquiry/Exit.vue').default },
    { path: '/estimate', component: require('./components/Invoice/Estimate.vue').default },
    { path: '/actual', component: require('./components/Invoice/Actual.vue').default },
    { path: '/dashboard', component: require('./components/Dashboard.vue').default },
    { path: '/profile', component: require('./components/Profile.vue').default },
    { path: '/developer', component: require('./components/Developer.vue').default },
    { path: '/users', component: require('./components/Users.vue').default },
    { path: '/shipschedules', component: require('./components/Shipschedules.vue').default },
    { path: '/invoice', component: require('./components/Invoice.vue').default },
    { path: '/payment', component: require('./components/Payment.vue').default },
    { path: '/courier', component: require('./components/Courier.vue').default },
    { path: '/courier-records', component: require('./components/CourierTable.vue').default },
    { path: '/add', component: require('./components/AddNew.vue').default },
    { path: '/tracking', component: require('./components/tracking.vue').default },


  



 

   


    { path: '*', component: require('./components/NotFound.vue').default }
];
