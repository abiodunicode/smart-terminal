<nav class="mt-2">
  <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
    <li class="nav-item">
      <router-link to="/dashboard" class="nav-link">
        <i class="nav-icon fas fa-tachometer-alt blue"></i>
        <p>
          Dashboard
        </p>
      </router-link>
    </li>
    <?php if(Route::has('login')): ?>
    <li class="nav-item">
      <?php if(auth()->guard()->check()): ?>
      <a href="<?php echo e(url('/home')); ?>" class="nav-link">
        <i class="nav-icon fas fa-question green"></i>
        <p>
          Go Home
        </p>
      </a>
    </li>
    <?php else: ?>
    <li class="nav-item">
      <a href="<?php echo e(route('login')); ?>" class="nav-link">
        <i class="nav-icon fas fa-sign-in-alt green"></i>
        <p>
          Login
        </p>
      </a>
    </li>
    <?php if(Route::has('register')): ?>
    <li class="nav-item">
      <a href="<?php echo e(route('register')); ?>" class="nav-link">
        <i class="nav-icon fas fa-registered blue"></i>
        <p>
          Register
        </p>
      </a>
      <?php endif; ?>
      <?php endif; ?>
    </li>
    <?php endif; ?>














  </ul>
</nav><?php /**PATH C:\Users\HP\Documents\2022-web-work\middle year\zan\resources\views/layouts/sidebar-menu-one.blade.php ENDPATH**/ ?>