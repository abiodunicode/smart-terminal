
<template>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header p-2">
                            <ul class="nav nav-pills">
                                
                                <li class="nav-item"><router-link to="/bl-cargo" class="nav-link active show">BL/Cargo Info</router-link></li>
                                <li class="nav-item"><router-link to="/Telex" class="nav-link w">Telex</router-link></li>
                                <li class="nav-item"><router-link to="/Exit" class="nav-link">Exit Note </router-link></li>
                              
                            </ul>
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <div class="tab-content">
                                <!-- Activity Tab -->
                                <div class="tab-pane active show" id="activity">
                                     <iframe 
                                height="500px"
                                width="100%"
                                frameborder="0"
                                allowTransparency="true"
                                scrolling="auto"
                                src='https://creatorapp.zohopublic.com/sageplatform/ebs/form-embed/BL_Inquiry/0UpjyHTz56AnvbU113pAm810GyyCR3MKhnUKX1XpGGETRVC6FeKQsDZzVnFSEjyGOjNrKuvhktPnvjkX236fhfsbgkpOGY5Zh58O'>    </iframe>
                                </div>
                                <!-- Setting Tab -->
                             

                                <!-- Setting Tab -->
                            
                            <!-- /.tab-pane -->
                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
            </div>
            <!-- end tabs -->
            </div>
        </div>
    </section>
</template>

<script>
    export default {
      
        mounted() {
            console.log('Component mounted.')
        },
      

       
    }
</script>


