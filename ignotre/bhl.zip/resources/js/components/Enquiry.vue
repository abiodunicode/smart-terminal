
<template>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header p-2">
                            <ul class="nav nav-pills">
                                <li class="nav-item"><a class="nav-link" href="#activity" data-toggle="tab">BL/Cargo Info. </a></li>
                                <li class="nav-item"><a class="nav-link active show" href="#settings" data-toggle="tab">Telex</a></li>
                                <li class="nav-item"><a class="nav-link" href="#change-password" data-toggle="tab">Exit Note </a></li>
                            </ul>
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <div class="tab-content">
                                <!-- Activity Tab -->
                                <div class="tab-pane" id="activity">
                                     <iframe class="_iframe"
              height="500px"
              width="300%"
              frameborder="0"
              allowTransparency="true"
              scrolling="auto"
              src="https://creatorapp.zohopublic.com/sageplatform/ebs/form-embed/Telex_Enquiry_Form/1qPOm2aAKzMUuWKQbQvAg6bfGjfThQtV2SX9u07uanp4R5bwJrGb91F00SfjBavmfRvvJudrQtpjY6HJXuPw1Cz8u5wYTU7D4ZWy"
            ></iframe>
                                </div>
                                <!-- Setting Tab -->
                                <div class="tab-pane active show" id="settings">
                                  <iframe
              height="500px"
              width="100%"
              frameborder="0"
              allowTransparency="true"
              scrolling="auto"
              src="https://creatorapp.zohopublic.com/sageplatform/ebs/form-embed/Telex_Enquiry_Form/1qPOm2aAKzMUuWKQbQvAg6bfGjfThQtV2SX9u07uanp4R5bwJrGb91F00SfjBavmfRvvJudrQtpjY6HJXuPw1Cz8u5wYTU7D4ZWy"
            ></iframe>
                                </div>

                                <!-- Setting Tab -->
                                <div class="tab-pane" id="change-password">
                                  <iframe
              height="500px"
              width="100%"
              frameborder="0"
              allowTransparency="true"
              scrolling="auto"
              src="https://creatorapp.zohopublic.com/sageplatform/ebs/form-embed/Exit_Note_Link_Enquiry/yJRjJ4OMUh2pfHtUmZHh8VjExzAmHPFxXDOnZE96U2R9kOVDUTsbK8GuMrCXmFwsJ42bZxQbqhgVFjNdZ5vrS0rAdDHaEBpaFJKQ"
            ></iframe>
                                </div>
                            <!-- /.tab-pane -->
                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
            </div>
            <!-- end tabs -->
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        data(){
            return {
                 form: new Form({
                    id:'',
                    name : '',
                    email: '',
                    password: '',
                    created_at: ''
                })
            }
        },
        mounted() {
            console.log('Component mounted.')
        },
        methods:{

            updateInfo(){
                this.$Progress.start();
                if(this.form.password == ''){
                    this.form.password = undefined;
                }
                this.form.put('api/profile')
                .then((data)=>{
                    this.$Progress.finish();
                    Toast.fire({
                        icon: 'success',
                        title: data.data.message
                    });
                })
                .catch((data) => {
                    this.$Progress.fail();

                    Toast.fire({
                        icon: 'error',
                        title: 'Some error occured! Please try again'
                    });
                });
            },

            updatePassword(){
                this.$Progress.start();
                this.form.post('api/change-password')
                .then((data)=>{
                    //  Fire.$emit('AfterCreate');
                    this.$Progress.finish();
                    this.form.current_password = '';
                    this.form.new_password = '';
                    this.form.confirm_password = '';

                    Toast.fire({
                        icon: 'success',
                        title: data.data.message
                    });
                })
                .catch(() => {
                    this.$Progress.fail();

                    Toast.fire({
                        icon: 'error',
                        title: 'Some error occured! Please try again'
                    });
                });
            }
        },

        created() {

            this.$Progress.start();

            axios.get("api/profile")
            .then(({ data }) => (this.form.fill(data.data)));
            
            this.$Progress.finish();
        }
    }
</script>

vue.<style scoped>
._iframe form {
    width: 100% !important;
}

.form[name="Telex_Enquiry_Form"].label-left {
    width: 100% !important;
}
</style>
