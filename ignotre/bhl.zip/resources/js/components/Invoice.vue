
<template>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header p-2">
                            <ul class="nav nav-pills">
                                <li class="nav-item"><a class="nav-link active show" href="#activity" data-toggle="tab">Estimate </a></li>
                                <li class="nav-item"><a class="nav-link " href="#settings" data-toggle="tab">Actual</a></li>
                            </ul>
                        </div><!-- /.card-header -->
                        <div class="card-body">
                            <div class="tab-content">
                                <!-- Activity Tab -->
                                <div class="tab-pane active show" id="activity">
                                       <iframe
              height="500px"
              width="100%"
              frameborder="0"
              allowTransparency="true"
              scrolling="auto"
              src="https://creatorapp.zohopublic.com/sageplatform/ebs/form-embed/Get_Estimated_Invoice/KAwNkOUZABrC8DQUC3jSOKmqQsah2RS84QbKgFOGQ0hpn7kkZxC0SrxAK2uOyE67Ch0mdAOnuZmt0r8HfsBWWbf1yFJ3XJOrBQyX"
            ></iframe>
                                </div>
                                <!-- Setting Tab -->
                                <div class="tab-pane " id="settings">
                             <iframe
              height="500px"
              width="100%"
              frameborder="0"
              allowTransparency="true"
              scrolling="auto"
              src="https://creatorapp.zohopublic.com/sageplatform/ebs/form-embed/Get_Actual_Online_Shipping_Invoice/PnjTpuHH5e9YsD8HVgypZABdgBdxB5k0skzTf5QDXC9s6YdDCGn0uevNJhApjvYwsjVqW6nhKkJthNZkCvGQdhyFF3SFDUx8xzEA"
            ></iframe>
                                </div>

                                <!-- Setting Tab -->
                               
                            <!-- /.tab-pane -->
                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
            </div>
            <!-- end tabs -->
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        data(){
            return {
                 form: new Form({
                    id:'',
                    name : '',
                    email: '',
                    password: '',
                    created_at: ''
                })
            }
        },
        mounted() {
            console.log('Component mounted.')
        },
        methods:{

            updateInfo(){
                this.$Progress.start();
                if(this.form.password == ''){
                    this.form.password = undefined;
                }
                this.form.put('api/profile')
                .then((data)=>{
                    this.$Progress.finish();
                    Toast.fire({
                        icon: 'success',
                        title: data.data.message
                    });
                })
                .catch((data) => {
                    this.$Progress.fail();

                    Toast.fire({
                        icon: 'error',
                        title: 'Some error occured! Please try again'
                    });
                });
            },

            updatePassword(){
                this.$Progress.start();
                this.form.post('api/change-password')
                .then((data)=>{
                    //  Fire.$emit('AfterCreate');
                    this.$Progress.finish();
                    this.form.current_password = '';
                    this.form.new_password = '';
                    this.form.confirm_password = '';

                    Toast.fire({
                        icon: 'success',
                        title: data.data.message
                    });
                })
                .catch(() => {
                    this.$Progress.fail();

                    Toast.fire({
                        icon: 'error',
                        title: 'Some error occured! Please try again'
                    });
                });
            }
        },

        created() {

            this.$Progress.start();

            axios.get("api/profile")
            .then(({ data }) => (this.form.fill(data.data)));
            
            this.$Progress.finish();
        }
    }
</script>
