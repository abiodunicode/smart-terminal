<?php if(auth()->guard()->check()): ?>
<script>
  window.user = <?php echo json_encode(auth()->user(), 15, 512) ?>
</script>
<?php endif; ?><?php /**PATH C:\Users\HP\Documents\2022-web-work\middle year\zan\resources\views/layouts/auth.blade.php ENDPATH**/ ?>